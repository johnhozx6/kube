package com.example.demokub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemokubApplicationTests {

	@Test
	void contextLoads() {
	}

}
