package com.example.demokub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemokubApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemokubApplication.class, args);
	}

}
