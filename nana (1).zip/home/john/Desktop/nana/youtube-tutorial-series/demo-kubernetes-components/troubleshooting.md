## Issue mongo-express or mongo-db pods not starting or giving an error
Use the docker driver for minikube by simply running `minikube start` without specifying the driver


_Simple installation guide for Minikube: https://minikube.sigs.k8s.io/docs/start/_
